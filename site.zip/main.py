from EdVenture.taverna import app
from EdVenture.taverna.routes import *

# os cadastros utilizarão "SQL ALCHEMY DO FLASK"
# os formulários utilizarão "WTF FORMS FLASK  "

if __name__ == "__main__":
    app.run(debug=True)